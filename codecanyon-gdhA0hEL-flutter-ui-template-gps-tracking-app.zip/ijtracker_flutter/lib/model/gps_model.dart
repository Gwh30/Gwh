/*
this is gps_model pages
used in history_map.dart
 */

class GpsModel {
  String _speed;
  int _direction;
  int _battery;
  String _gpsDate;
  String _mileage;
  String _stopTime;
  double _lat;
  double _long;

  GpsModel(this._speed, this._direction, this._battery, this._gpsDate, this._mileage, this._stopTime, this._lat, this._long);

  String get getSpeed{
    return _speed;
  }

  int get getDirection{
    return _direction;
  }

  int get getBattery{
    return _battery;
  }

  String get getGpsDate{
    return _gpsDate;
  }

  String get getMileage{
    return _mileage;
  }

  String get getStopTime{
    return _stopTime;
  }

  double get getLat{
    return _lat;
  }

  double get getLong{
    return _long;
  }
}
