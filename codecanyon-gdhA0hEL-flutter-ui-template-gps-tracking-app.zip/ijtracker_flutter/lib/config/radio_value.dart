/*
this is radio value pages
 */

// This value is used for radio button in add_device.dart & edit_device.dart
enum IconValue {
  man,
  woman,
  pregnant,
  elderly,
  child,
  disability,
  pet,
  car,
  bike,
  truck,
  boat
}

// This value is used for radio button in history_gps.dart
enum HistoryValue {
  today,
  yesterday,
  other
}