/*
this is constant pages

install plugin in pubspec.yaml
- google_maps_flutter => for google maps (https://pub.dev/packages/google_maps_flutter)
  add google maps api key to android manifest :
  <manifest ...
  <application ...
    <meta-data android:name="com.google.android.geo.API_KEY"
               android:value="YOUR KEY HERE"/>

  add google maps api key to ios/Runner/AppDelegate.swift
  import UIKit
  import Flutter
  import GoogleMaps

  @UIApplicationMain
  @objc class AppDelegate: FlutterAppDelegate {
    override func application(
      _ application: UIApplication,
      didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
      GMSServices.provideAPIKey("YOUR KEY HERE")
      GeneratedPluginRegistrant.register(with: self)
      return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
  }

 */

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

const String APP_NAME = 'iJTracker Flutter';

// color for apps
const Color PRIMARY_COLOR = Color(0xFF0181cc);
const Color ASSENT_COLOR = Color(0xFFe75f3f);
const Color GRADIENT_TOP = Color(0xFF039be6);
const Color GRADIENT_BOTTOM = Color(0xFF0299e2);

const Color MENU_IMAGES_COLOR = Color(0xFF057DC3);
const Color MAPS_IMAGES_COLOR = Color(0xFF0a4349);
const Color CHARCOAL = Color(0xFF515151);
const Color OCEAN = Color(0xFF00ace9);

// image picture
const String IMAGES_URL = 'https://cdn.shopify.com/s/files/1/1898/4483/files/never-run-out.png';

// dummy device 1
const String SN1 = '7018089100';
const String DEV_NAME1 = 'B 2455 UJD';
const String DEV_DESC1 = 'I put this GPS Tracker in my Honda car';
const String DEV_STATUS1 = 'Online';
const int DEV_POWER1 = 90;
const String ICON_NAME1 = 'car';
const DEV_ICON1 = Icons.directions_car;
const double GPS_LAT1 = -6.168033;
const double GPS_LNG1 = 106.900467;
const LatLng GPS_POSITION1 = LatLng(-6.168033, 106.900467);
const String GPS_SPEED1 = '51 Km/h';
const String GPS_DATE1 = '2020-07-15 09:02:31';

// dummy device 2
const String SN2 = '7028129300';
const String DEV_NAME2 = 'My Mom';
const String DEV_DESC2 = 'I give this GPS Tracker to my mom';
const String DEV_STATUS2 = 'Subscribe Expired';
const int DEV_POWER2 = 73;
const String ICON_NAME2 = 'elderly';
const DEV_ICON2 = AssetImage('assets/images/elderly.png');
const double GPS_LAT2 = -6.164770;
const double GPS_LNG2 = 106.900630;
const LatLng GPS_POSITION2 = LatLng(-6.164770, 106.900630);
const String GPS_SPEED2 = '21 Km/h';
const String GPS_DATE2 = '2020-07-14 19:23:27';

// dummy device 3
const String SN3 = '4209995000';
const String DEV_NAME3 = 'B 4245 UTR';
const String DEV_DESC3 = 'I put this GPS Tracker in my motorcycle';
const String DEV_STATUS3 = 'Power Saving';
const int DEV_POWER3 = 9;
const String ICON_NAME3 = 'bike';
const DEV_ICON3 = Icons.motorcycle;
const double GPS_LAT3 = -6.158637;
const double GPS_LNG3 = 106.906376;
const LatLng GPS_POSITION3 = LatLng(-6.158637, 106.906376);
const String GPS_SPEED3 = '34 Km/h';
const String GPS_DATE3 = '2020-07-15 11:05:01';

// dummy geofence 1
const String GEO_NAME1 = 'Office Area';
const String GEO_DESC1 = 'This is the area of my office, it is around 200 meters';
const double GEO_LAT1 = -6.168033;
const double GEO_LNG1 = 106.900467;
const double GEO_RAD1 = 200;

// dummy geofence 2
const String GEO_NAME2 = 'Home Area';
const String GEO_DESC2 = 'This is the area of my home, it is around 150 meters';
const double GEO_LAT2 = -6.162608;
const double GEO_LNG2 = 106.901966;
const double GEO_RAD2 = 150;

// dummy geofence 3
const String GEO_NAME3 = 'Lotte Mart Area';
const String GEO_DESC3 = 'This is the area of Lotte Mart, it is around 165 meters';
const double GEO_LAT3 = -6.153578;
const double GEO_LNG3 = 106.895669;
const double GEO_RAD3 = 165;

// dummy geofence 4
const String GEO_NAME4 = 'Sunlake Hotel';
const String GEO_DESC4 = 'This is the area of Sunlake Hotel, it is around 130 meters';
const double GEO_LAT4 = -6.146770;
const double GEO_LNG4 = 106.880045;
const double GEO_RAD4 = 130;

// dummy geofence 5
const String GEO_NAME5 = 'Monas Area';
const String GEO_DESC5 = 'This is the area of Monas, it is around 560 meters';
const double GEO_LAT5 = -6.175144;
const double GEO_LNG5 = 106.827104;
const double GEO_RAD5 = 560;

// dummy geofence 6
const String GEO_NAME6 = 'GBK Area';
const String GEO_DESC6 = 'This is the area of Monas, it is around 740 meters';
const double GEO_LAT6 = -6.218392;
const double GEO_LNG6 = 106.802737;
const double GEO_RAD6 = 740;

// dummy geofence 7
const String GEO_NAME7 = 'Central Park Jakarta';
const String GEO_DESC7 = 'This is the area of Central Park Mall in Jakarta, it is around 170 meters';
const double GEO_LAT7 = -6.177228;
const double GEO_LNG7 = 106.790634;
const double GEO_RAD7 = 170;