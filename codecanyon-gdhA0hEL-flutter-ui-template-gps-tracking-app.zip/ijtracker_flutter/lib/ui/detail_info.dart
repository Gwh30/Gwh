/*
This is detail info page

install plugin in pubspec.yaml
- url_launcher => used for call function (https://pub.dev/packages/url_launcher)
 */

import 'package:flutter/material.dart';
import 'package:ijtrackerflutter/config/constants.dart';
import 'package:url_launcher/url_launcher.dart' as UrlLauncher;

class DetailInfoPage extends StatefulWidget {
  @override
  _DetailInfoPageState createState() => _DetailInfoPageState();
}

class _DetailInfoPageState extends State<DetailInfoPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            'DETAIL INFO',
            style: TextStyle(
              fontSize: 16,
            ),
          ),
          backgroundColor: PRIMARY_COLOR,
        ),
        body: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SizedBox(
                  height: 10,
                ),
                Text(
                  'GPS Name',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      DEV_NAME1,
                      style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                    ),
                    Wrap(
                      children: <Widget>[
                        Icon(DEV_ICON1, size: 28, color: MENU_IMAGES_COLOR),
                        SizedBox(width: 10),
                        Container(
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.lightGreen[700]),
                              borderRadius: BorderRadius.circular(50)),
                          padding: EdgeInsets.fromLTRB(15, 5, 15, 3),
                          child: Text(DEV_STATUS1,
                              maxLines: 1,
                              style: TextStyle(
                                  color: Colors.lightGreen[700], fontSize: 14)),
                        ),
                      ],
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'GPS Description',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  DEV_DESC1,
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'GPS Phone Number',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      '+62811456789',
                      style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                    ),
                    GestureDetector(
                      onTap: () {
                        UrlLauncher.launch('tel:+62811456789');
                      },
                      child: Text(
                        'Call',
                        style: TextStyle(
                            fontSize: 16,
                            color: PRIMARY_COLOR,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Text(
                  'Devices can only be called by the center number',
                  style: TextStyle(fontSize: 12, color: OCEAN),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Serial Number',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  SN1,
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Battery',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  DEV_POWER1.toString()+' %',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Interval GPS',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  '20 second',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Status',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Subscribe',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Subscribe Date',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  '21 February 2020',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Upgrade Date',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  '21 February 2020',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Expired Date',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[700],
                      fontWeight: FontWeight.normal),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  '21 February 2021',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ));
  }
}
