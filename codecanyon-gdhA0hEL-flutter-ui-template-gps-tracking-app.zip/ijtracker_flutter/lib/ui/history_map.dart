/*
This is history map page
if you don't use _mapLoading variable, when the first time maps is loaded, you will see black screen for a while.

install plugin in pubspec.yaml
- google_maps_flutter => for google maps (https://pub.dev/packages/google_maps_flutter)
  add google maps api key to android manifest :
  <manifest ...
  <application ...
    <meta-data android:name="com.google.android.geo.API_KEY"
               android:value="YOUR KEY HERE"/>

  add google maps api key to ios/Runner/AppDelegate.swift
  import UIKit
  import Flutter
  import GoogleMaps

  @UIApplicationMain
  @objc class AppDelegate: FlutterAppDelegate {
    override func application(
      _ application: UIApplication,
      didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
      GMSServices.provideAPIKey("YOUR KEY HERE")
      GeneratedPluginRegistrant.register(with: self)
      return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
  }

- intl => for function DateFormat (https://pub.dev/packages/intl)

Don't forget to add all images and sound used in this pages at the pubspec.yaml
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ijtrackerflutter/config/constants.dart';
import 'package:ijtrackerflutter/model/gps_model.dart';
import 'package:intl/intl.dart';

class HistoryMapPage extends StatefulWidget {
  final String date;

  // create constructor to get variable already sent from history_gps.dart page
  const HistoryMapPage({Key key, this.date = ''}) : super(key: key);

  @override
  _HistoryMapPageState createState() => _HistoryMapPageState();
}

class _HistoryMapPageState extends State<HistoryMapPage> {
  GoogleMapController _controller;
  bool _mapLoading = true;
  Timer _timerDummy;

  final LatLng _initialPosition = LatLng(-4.207917, 112.1031403);

  // variable to mapping all markers and polylines
  Map<MarkerId, Marker> _allMarker = {};
  List<LatLng> _latlng = List();
  bool _isBound = false;
  bool _doneListing = false;
  Map<PolylineId, Polyline> _mapPolylines = {};

  // gps detail data information
  bool _infoDetail = true;
  String _speed = '';
  String _gpsDate = '';
  String _stopTime = '';
  String _mileage = '';

  // variable for progress bar
  double _valProgress = 0, _valSpeed = 1;
  bool _playHistory = false;

  // this function is used to play the history of marker
  Timer _timer;
  void _startTimer() {
    if(_valProgress==_gpsList.length-1){
      if (_showMarker == false) {
        _allMarker[MarkerId(_valProgress
            .round()
            .toString())] = _allMarker[
        MarkerId(_valProgress
            .round()
            .toString())]
            .copyWith(
          visibleParam: false,
        );
      }

      _changeSliderProgress(0);
    }
    _timer = Timer.periodic(
      Duration(milliseconds: 1000~/_valSpeed), (Timer timer) {
      if (_valProgress.toInt() >= _gpsList.length-1) {
        timer.cancel();
        setState(() {
          _playHistory = (_playHistory) ? false : true;
        });
      } else {
        if (_showMarker == false) {
          _allMarker[MarkerId(_valProgress
              .round()
              .toString())] = _allMarker[
          MarkerId(_valProgress
              .round()
              .toString())]
              .copyWith(
            visibleParam: false,
          );
        }

        double newVal = _valProgress+1;
        _changeSliderProgress(newVal);
      }
    },
    );
  }

  void _changeSliderProgress(double val){
    setState(() {
      _valProgress = val;

      _speed = _gpsList[_valProgress.round()].getSpeed;
      _mileage = _gpsList[_valProgress.round()].getMileage;
      _gpsDate = _gpsList[_valProgress.round()].getGpsDate;
      _stopTime = _gpsList[_valProgress.round()].getStopTime;

      _infoDetail = true;

      if (_showMarker == false) {
        _allMarker[MarkerId(_valProgress.round().toString())] =
            _allMarker[MarkerId(_valProgress.round().toString())]
                .copyWith(
              visibleParam: true,
            );
      } else {
        _allMarker[MarkerId(_valProgress.round().toString())] =
            _allMarker[MarkerId(_valProgress.round().toString())]
                .copyWith(
              zIndexParam:
              9999, //infoWindowParam: InfoWindow(title: 'here')
            );
      }
      _controller.getZoomLevel().then((zoom) {
        _currentZoom = zoom;
        _controller.moveCamera(CameraUpdate.newCameraPosition(
            CameraPosition(
                target: LatLng(_gpsList[_valProgress.round()].getLat, _gpsList[_valProgress.round()].getLong),
                zoom: zoom)));
      });
    });
  }

  double _currentZoom;

  bool _showMarker = false;

  // this is dummy gps list
  List<GpsModel> _gpsList = new List();
  void _addDummyGps(){
    _gpsList.add(new GpsModel('26.68 Km/h', 288, 100, '2019-10-12 01:05:53', '0 m', '', -6.1529818, 106.9065));
    _gpsList.add(new GpsModel('40.13 Km/h', 300, 100, '2019-10-12 01:06:13', '42 m', '', -6.1518784, 106.904816));
    _gpsList.add(new GpsModel('34.8 Km/h', 297, 100, '2019-10-12 01:06:33', '300 m', '', -6.150978, 106.90332));
    _gpsList.add(new GpsModel('27.6 Km/h', 303, 100, '2019-10-12 01:07:33', '807 m', '', -6.14868, 106.89986));
    _gpsList.add(new GpsModel('21.86 Km/h', 287, 100, '2019-10-12 01:07:53', '1.1 km', '', -6.14783, 106.89917));
    _gpsList.add(new GpsModel('30.6 Km/h', 295, 100, '2019-10-12 01:08:12', '1.66 km', '', -6.147168, 106.89787));
    _gpsList.add(new GpsModel('28.39 Km/h', 296, 100, '2019-10-12 01:08:32', '2.01 km', '', -6.1464667, 106.89663));
    _gpsList.add(new GpsModel('36.45 Km/h', 299, 100, '2019-10-12 01:08:52', '2.72 km', '', -6.1456165, 106.89501));
    _gpsList.add(new GpsModel('34.63 Km/h', 297, 100, '2019-10-12 01:09:06', '2.85 km', '', -6.145045, 106.893936));
    _gpsList.add(new GpsModel('27.88 Km/h', 292, 100, '2019-10-12 01:09:12', '2.9 km', '', -6.1448684, 106.893555));
    _gpsList.add(new GpsModel('26.61 Km/h', 298, 100, '2019-10-12 01:09:32', '3.05 km', '', -6.144252, 106.89237));
    _gpsList.add(new GpsModel('19.58 Km/h', 286, 100, '2019-10-12 01:09:52', '3.15 km', '', -6.143835, 106.89148));
    _gpsList.add(new GpsModel('18.49 Km/h', 192, 100, '2019-10-12 01:11:11', '3.56 km', '', -6.1471434, 106.88993));
    _gpsList.add(new GpsModel('28.49 Km/h', 217, 100, '2019-10-12 01:11:31', '3.72 km', '', -6.1485415, 106.88966));
    _gpsList.add(new GpsModel('15.79 Km/h', 201, 100, '2019-10-12 01:12:11', '3.89 km', '', -6.1499968, 106.889046));
    _gpsList.add(new GpsModel('49.13 Km/h', 213, 100, '2019-10-12 01:12:31', '4.17 km', '', -6.1521215, 106.88781));
    _gpsList.add(new GpsModel('69.58 Km/h', 211, 100, '2019-10-12 01:12:50', '4.53 km', '', -6.154947, 106.88609));
    _gpsList.add(new GpsModel('74.53 Km/h', 210, 100, '2019-10-12 01:13:10', '4.95 km', '', -6.158135, 106.884155));
    _gpsList.add(new GpsModel('80.21 Km/h', 211, 100, '2019-10-12 01:13:30', '5.39 km', '', -6.1615767, 106.88209));
    _gpsList.add(new GpsModel('81.45 Km/h', 212, 100, '2019-10-12 01:13:50', '5.85 km', '', -6.1650085, 106.87989));
    _gpsList.add(new GpsModel('73.99 Km/h', 184, 100, '2019-10-12 01:15:29', '7.88 km', '', -6.1828265, 106.875694));
    _gpsList.add(new GpsModel('75.11 Km/h', 182, 100, '2019-10-12 01:15:49', '8.3 km', '', -6.186575, 106.87552));
    _gpsList.add(new GpsModel('70.07 Km/h', 182, 100, '2019-10-12 01:16:09', '8.69 km', '', -6.1900735, 106.87539));
    _gpsList.add(new GpsModel('70.85 Km/h', 192, 100, '2019-10-12 01:16:29', '9.08 km', '', -6.1935782, 106.87489));
    _gpsList.add(new GpsModel('68.1 Km/h', 190, 100, '2019-10-12 01:16:49', '9.46 km', '', -6.1969185, 106.87424));
    _gpsList.add(new GpsModel('77.78 Km/h', 179, 100, '2019-10-12 01:17:48', '10.73 km', '', -6.2083783, 106.87396));
    _gpsList.add(new GpsModel('77.35 Km/h', 176, 100, '2019-10-12 01:18:08', '11.16 km', '', -6.21224, 106.87411));
    _gpsList.add(new GpsModel('80.88 Km/h', 177, 100, '2019-10-12 01:18:28', '11.61 km', '', -6.2162786, 106.87425));
    _gpsList.add(new GpsModel('72.72 Km/h', 177, 100, '2019-10-12 01:18:48', '12.02 km', '', -6.219908, 106.87442));
    _gpsList.add(new GpsModel('64.44 Km/h', 174, 100, '2019-10-12 01:19:08', '12.38 km', '', -6.22312, 106.87464));
    _gpsList.add(new GpsModel('65.21 Km/h', 168, 100, '2019-10-12 01:19:28', '12.74 km', '', -6.226343, 106.87512));
    _gpsList.add(new GpsModel('67.12 Km/h', 166, 100, '2019-10-12 01:19:40', '12.96 km', '', -6.228307, 106.87556));
    _gpsList.add(new GpsModel('70.65 Km/h', 165, 100, '2019-10-12 01:19:48', '13.12 km', '', -6.2296815, 106.875885));
    _gpsList.add(new GpsModel('80.54 Km/h', 166, 100, '2019-10-12 01:20:07', '13.54 km', '', -6.233392, 106.87681));
    _gpsList.add(new GpsModel('80.24 Km/h', 165, 100, '2019-10-12 01:20:27', '13.99 km', '', -6.237282, 106.877785));
    _gpsList.add(new GpsModel('65.54 Km/h', 202, 100, '2019-10-12 01:20:47', '14.35 km', '', -6.240555, 106.877884));
    _gpsList.add(new GpsModel('71.38 Km/h', 177, 100, '2019-10-12 01:21:07', '14.75 km', '', -6.2440667, 106.87726));
    _gpsList.add(new GpsModel('70.51 Km/h', 203, 100, '2019-10-12 01:21:27', '15.14 km', '', -6.2475767, 106.87696));
    _gpsList.add(new GpsModel('62.23 Km/h', 231, 100, '2019-10-12 01:21:47', '15.49 km', '', -6.250147, 106.8752));
    _gpsList.add(new GpsModel('69.72 Km/h', 201, 100, '2019-10-12 01:22:07', '15.87 km', '', -6.252775, 106.8729));
    _gpsList.add(new GpsModel('77.36 Km/h', 162, 100, '2019-10-12 01:22:26', '16.28 km', '', -6.256435, 106.872604));
    _gpsList.add(new GpsModel('68.23 Km/h', 179, 100, '2019-10-12 01:22:46', '16.66 km', '', -6.259775, 106.87329));
    _gpsList.add(new GpsModel('66.47 Km/h', 183, 100, '2019-10-12 01:23:06', '17.03 km', '', -6.2630935, 106.87316));
    _gpsList.add(new GpsModel('68.28 Km/h', 173, 100, '2019-10-12 01:23:26', '17.41 km', '', -6.2665014, 106.873314));
    _gpsList.add(new GpsModel('68.99 Km/h', 185, 100, '2019-10-12 01:23:46', '17.79 km', '', -6.26991, 106.8728));
    _gpsList.add(new GpsModel('61.88 Km/h', 171, 100, '2019-10-12 01:24:06', '18.14 km', '', -6.273, 106.872894));
    _gpsList.add(new GpsModel('66.35 Km/h', 161, 100, '2019-10-12 01:24:26', '18.51 km', '', -6.276242, 106.87359));
    _gpsList.add(new GpsModel('70.18 Km/h', 156, 100, '2019-10-12 01:24:37', '18.72 km', '', -6.278052, 106.87426));
    _gpsList.add(new GpsModel('58.83 Km/h', 157, 100, '2019-10-12 01:24:45', '18.85 km', '', -6.2791433, 106.8747));
    _gpsList.add(new GpsModel('62.61 Km/h', 158, 100, '2019-10-12 01:25:05', '19.2 km', '', -6.2820415, 106.875885));
    _gpsList.add(new GpsModel('55.04 Km/h', 157, 100, '2019-10-12 01:25:25', '19.51 km', '', -6.2845917, 106.87692));
    _gpsList.add(new GpsModel('73.99 Km/h', 157, 100, '2019-10-12 01:25:45', '19.92 km', '', -6.287998, 106.878365));
    _gpsList.add(new GpsModel('73.7 Km/h', 157, 100, '2019-10-12 01:26:05', '20.33 km', '', -6.291405, 106.87977));
    _gpsList.add(new GpsModel('58.38 Km/h', 155, 100, '2019-10-12 01:26:25', '20.65 km', '', -6.294105, 106.88088));
    _gpsList.add(new GpsModel('60.42 Km/h', 158, 100, '2019-10-12 01:26:45', '20.99 km', '', -6.2968783, 106.88208));
    _gpsList.add(new GpsModel('54.73 Km/h', 161, 100, '2019-10-12 01:27:04', '21.27 km', '', -6.2993135, 106.88299));
    _gpsList.add(new GpsModel('13.27 Km/h', 171, 100, '2019-10-12 01:27:44', '21.42 km', '', -6.30059, 106.88335));
    _gpsList.add(new GpsModel('47.77 Km/h', 172, 100, '2019-10-12 01:28:04', '21.69 km', '', -6.3028984, 106.88396));
    _gpsList.add(new GpsModel('48.74 Km/h', 125, 100, '2019-10-12 01:28:24', '21.96 km', '', -6.304545, 106.885765));
    _gpsList.add(new GpsModel('35.04 Km/h', 251, 100, '2019-10-12 01:28:44', '22.15 km', '', -6.3062334, 106.88623));
    _gpsList.add(new GpsModel('63.84 Km/h', 270, 100, '2019-10-12 01:29:04', '22.51 km', '', -6.306053, 106.883026));
    _gpsList.add(new GpsModel('70.56 Km/h', 254, 100, '2019-10-12 01:29:23', '22.88 km', '', -6.306588, 106.8797));
    _gpsList.add(new GpsModel('73.46 Km/h', 255, 100, '2019-10-12 01:29:35', '23.12 km', '', -6.30712, 106.87755));
    _gpsList.add(new GpsModel('77.33 Km/h', 255, 100, '2019-10-12 01:29:43', '23.3 km', '', -6.3075085, 106.876045));
    _gpsList.add(new GpsModel('67.65 Km/h', 258, 100, '2019-10-12 01:30:03', '23.67 km', '', -6.3083434, 106.87275));
    _gpsList.add(new GpsModel('72.65 Km/h', 290, 100, '2019-10-12 01:30:23', '24.08 km', '', -6.30846, 106.8691));
    _gpsList.add(new GpsModel('74.01 Km/h', 296, 100, '2019-10-12 01:30:43', '24.49 km', '', -6.306852, 106.86575));
    _gpsList.add(new GpsModel('75.86 Km/h', 270, 100, '2019-10-12 01:31:03', '24.91 km', '', -6.30552, 106.86218));
    _gpsList.add(new GpsModel('76.36 Km/h', 266, 100, '2019-10-12 01:31:23', '25.33 km', '', -6.3056784, 106.858345));
    _gpsList.add(new GpsModel('79.83 Km/h', 295, 100, '2019-10-12 01:31:42', '25.75 km', '', -6.3051085, 106.854576));
    _gpsList.add(new GpsModel('81.42 Km/h', 269, 100, '2019-10-12 01:32:02', '26.21 km', '', -6.3043785, 106.85055));
    _gpsList.add(new GpsModel('77.51 Km/h', 276, 100, '2019-10-12 01:32:22', '26.64 km', '', -6.3041015, 106.846664));
    _gpsList.add(new GpsModel('78.78 Km/h', 279, 100, '2019-10-12 01:32:42', '27.07 km', '', -6.3036118, 106.842735));
    _gpsList.add(new GpsModel('80.49 Km/h', 287, 100, '2019-10-12 01:33:02', '27.52 km', '', -6.3027835, 106.838776));
    _gpsList.add(new GpsModel('85.25 Km/h', 305, 100, '2019-10-12 01:33:22', '28 km', '', -6.3007884, 106.83499));
    _gpsList.add(new GpsModel('73.54 Km/h', 291, 100, '2019-10-12 01:34:41', '29.61 km', '', -6.293825, 106.82218));
    _gpsList.add(new GpsModel('56.92 Km/h', 291, 100, '2019-10-12 01:34:44', '29.66 km', '', -6.2936583, 106.821785));
    _gpsList.add(new GpsModel('63.79 Km/h', 286, 100, '2019-10-12 01:35:01', '29.96 km', '', -6.292715, 106.81923));
    _gpsList.add(new GpsModel('63.03 Km/h', 270, 100, '2019-10-12 01:35:21', '30.31 km', '', -6.2923265, 106.816086));
    _gpsList.add(new GpsModel('40.15 Km/h', 272, 100, '2019-10-12 01:35:41', '30.53 km', '', -6.292238, 106.81407));
    _gpsList.add(new GpsModel('47.95 Km/h', 268, 100, '2019-10-12 01:36:01', '30.8 km', '', -6.292195, 106.81166));
    _gpsList.add(new GpsModel('62.35 Km/h', 267, 100, '2019-10-12 01:36:20', '31.13 km', '', -6.2923083, 106.808685));
    _gpsList.add(new GpsModel('42.72 Km/h', 268, 100, '2019-10-12 01:36:40', '31.36 km', '', -6.29241, 106.80654));
    _gpsList.add(new GpsModel('46.77 Km/h', 269, 100, '2019-10-12 01:37:00', '31.62 km', '', -6.2924666, 106.80419));
    _gpsList.add(new GpsModel('51.13 Km/h', 271, 100, '2019-10-12 01:37:20', '31.91 km', '', -6.29244, 106.80162));
    _gpsList.add(new GpsModel('51.93 Km/h', 271, 100, '2019-10-12 01:37:40', '32.2 km', '', -6.292395, 106.79901));
    _gpsList.add(new GpsModel('46.96 Km/h', 270, 100, '2019-10-12 01:38:00', '32.46 km', '', -6.29235, 106.79665));
    _gpsList.add(new GpsModel('53.33 Km/h', 270, 100, '2019-10-12 01:38:20', '32.75 km', '', -6.2922935, 106.79397));
    _gpsList.add(new GpsModel('52.98 Km/h', 269, 100, '2019-10-12 01:38:39', '33.03 km', '', -6.2922735, 106.79144));
    _gpsList.add(new GpsModel('46.77 Km/h', 270, 100, '2019-10-12 01:38:59', '33.29 km', '', -6.2923317, 106.78909));
    _gpsList.add(new GpsModel('34.62 Km/h', 272, 100, '2019-10-12 01:39:19', '33.49 km', '', -6.292333, 106.78735));
    _gpsList.add(new GpsModel('46.64 Km/h', 286, 100, '2019-10-12 01:39:39', '33.74 km', '', -6.2919717, 106.785034));
    _gpsList.add(new GpsModel('47.18 Km/h', 287, 100, '2019-10-12 01:39:42', '33.78 km', '', -6.2918816, 106.78469));
    _gpsList.add(new GpsModel('50.4 Km/h', 284, 100, '2019-10-12 01:39:59', '34.02 km', '', -6.2912917, 106.78262));
    _gpsList.add(new GpsModel('46.48 Km/h', 299, 100, '2019-10-12 01:40:19', '34.28 km', '', -6.29051, 106.78042));
    _gpsList.add(new GpsModel('37.08 Km/h', 311, 100, '2019-10-12 01:40:39', '34.49 km', '', -6.289505, 106.778854));
    _gpsList.add(new GpsModel('6.8 Km/h', 353, 100, '2019-10-12 01:41:58', '34.64 km', '', -6.2885265, 106.77793));
    _gpsList.add(new GpsModel('32.23 Km/h', 54, 100, '2019-10-12 01:42:18', '34.81 km', '', -6.2874784, 106.77916));
    _gpsList.add(new GpsModel('40.33 Km/h', 357, 100, '2019-10-12 01:42:38', '35.04 km', '', -6.2857733, 106.78024));
    _gpsList.add(new GpsModel('34.68 Km/h', 357, 100, '2019-10-12 01:42:58', '35.23 km', '', -6.284042, 106.780174));
    _gpsList.add(new GpsModel('38 Km/h', 7, 100, '2019-10-12 01:43:17', '35.43 km', '', -6.2822385, 106.7802));
    _gpsList.add(new GpsModel('25.95 Km/h', 14, 100, '2019-10-12 01:43:37', '35.58 km', '', -6.280968, 106.78046));
    _gpsList.add(new GpsModel('17.49 Km/h', 20, 100, '2019-10-12 01:43:57', '35.67 km', '', -6.2800965, 106.780525));
    _gpsList.add(new GpsModel('2.1 Km/h', 108, 100, '2019-10-12 01:44:40', '35.7 km', '', -6.28, 106.78073));
    _gpsList.add(new GpsModel('6.94 Km/h', 132, 100, '2019-10-12 01:45:17', '35.77 km', '', -6.280393, 106.78124));
    _gpsList.add(new GpsModel('44.04 Km/h', 107, 100, '2019-10-12 01:45:36', '36 km', '', -6.2810683, 106.78323));
    _gpsList.add(new GpsModel('34.17 Km/h', 138, 100, '2019-10-12 01:45:56', '36.19 km', '', -6.281783, 106.78479));
    _gpsList.add(new GpsModel('45.01 Km/h', 148, 100, '2019-10-12 01:46:16', '36.44 km', '', -6.283408, 106.786354));
    _gpsList.add(new GpsModel('25.8 Km/h', 82, 100, '2019-10-12 01:46:36', '36.58 km', '', -6.284245, 106.78734));
    _gpsList.add(new GpsModel('19.62 Km/h', 28, 100, '2019-10-12 01:46:56', '36.69 km', '', -6.2834315, 106.78789));
    _gpsList.add(new GpsModel('15.74 Km/h', 35, 100, '2019-10-12 01:47:16', '36.78 km', '', -6.2827716, 106.78832));
    _gpsList.add(new GpsModel('6.97 Km/h', 49, 100, '2019-10-12 01:47:36', '36.82 km', '', -6.282688, 106.78866));
    _gpsList.add(new GpsModel('15.18 Km/h', 8, 100, '2019-10-12 01:47:55', '36.9 km', '', -6.2820415, 106.78898));
    _gpsList.add(new GpsModel('0.83 Km/h', 331, 100, '2019-10-12 01:49:38', '36.92 km', '', -6.2818565, 106.789085));
    _gpsList.add(new GpsModel('0.01 Km/h', 331, 100, '2019-10-12 01:54:36', '36.92 km', '3 hours 13 minutes', -6.281852, 106.78909));
    _gpsList.add(new GpsModel('0.01 Km/h', 179, 100, '2019-10-12 05:07:44', '36.95 km', '', -6.2820983, 106.789));
    _gpsList.add(new GpsModel('14.48 Km/h', 210, 100, '2019-10-12 05:08:04', '37.03 km', '', -6.282748, 106.78868));
    _gpsList.add(new GpsModel('17.18 Km/h', 216, 100, '2019-10-12 05:08:24', '37.13 km', '', -6.28334, 106.788055));
    _gpsList.add(new GpsModel('15.54 Km/h', 204, 100, '2019-10-12 05:08:34', '37.17 km', '', -6.28366, 106.787834));
    _gpsList.add(new GpsModel('12.49 Km/h', 211, 100, '2019-10-12 05:08:44', '37.21 km', '', -6.2839284, 106.787674));
    _gpsList.add(new GpsModel('8.94 Km/h', 209, 100, '2019-10-12 05:09:04', '37.26 km', '', -6.284313, 106.787445));
    _gpsList.add(new GpsModel('21.93 Km/h', 330, 100, '2019-10-12 05:09:23', '37.37 km', '', -6.2837334, 106.786575));
    _gpsList.add(new GpsModel('33.42 Km/h', 309, 100, '2019-10-12 05:09:43', '37.56 km', '', -6.2824383, 106.785515));
    _gpsList.add(new GpsModel('32.31 Km/h', 286, 100, '2019-10-12 05:10:03', '37.74 km', '', -6.281505, 106.78419));
    _gpsList.add(new GpsModel('33.71 Km/h', 283, 100, '2019-10-12 05:10:23', '37.93 km', '', -6.280872, 106.78262));
    _gpsList.add(new GpsModel('15.64 Km/h', 286, 100, '2019-10-12 05:10:43', '38.01 km', '', -6.280638, 106.78187));
    _gpsList.add(new GpsModel('2.69 Km/h', 239, 100, '2019-10-12 05:13:02', '38.12 km', '', -6.280452, 106.78095));
    _gpsList.add(new GpsModel('14.95 Km/h', 43, 100, '2019-10-12 05:13:22', '38.2 km', '', -6.2797117, 106.78085));
    _gpsList.add(new GpsModel('38.91 Km/h', 17, 100, '2019-10-12 05:13:32', '38.31 km', '', -6.278792, 106.781166));
    _gpsList.add(new GpsModel('51.95 Km/h', 13, 100, '2019-10-12 05:13:42', '38.45 km', '', -6.27754, 106.78151));
    _gpsList.add(new GpsModel('24.77 Km/h', 20, 100, '2019-10-12 05:15:41', '39.27 km', '', -6.270425, 106.783424));
    _gpsList.add(new GpsModel('11.05 Km/h', 10, 100, '2019-10-12 05:16:01', '39.33 km', '', -6.2698884, 106.783554));
    _gpsList.add(new GpsModel('9.96 Km/h', 1, 100, '2019-10-12 05:16:20', '39.38 km', '', -6.269417, 106.78359));
    _gpsList.add(new GpsModel('7.27 Km/h', 355, 100, '2019-10-12 05:17:00', '39.46 km', '', -6.2686915, 106.783554));
    _gpsList.add(new GpsModel('5.41 Km/h', 359, 100, '2019-10-12 05:17:20', '39.49 km', '', -6.2684216, 106.78354));
    _gpsList.add(new GpsModel('8.81 Km/h', 2, 100, '2019-10-12 05:17:40', '39.54 km', '', -6.2679815, 106.78354));
    _gpsList.add(new GpsModel('8.39 Km/h', 265, 100, '2019-10-12 05:18:00', '39.59 km', '', -6.267618, 106.78333));
    _gpsList.add(new GpsModel('4.82 Km/h', 13, 100, '2019-10-12 05:18:39', '39.64 km', '', -6.2672467, 106.78304));
    _gpsList.add(new GpsModel('5.23 Km/h', 1, 100, '2019-10-12 05:18:59', '39.67 km', '', -6.266987, 106.78307));
    _gpsList.add(new GpsModel('8.55 Km/h', 353, 100, '2019-10-12 05:19:19', '39.72 km', '', -6.26662, 106.78329));
    _gpsList.add(new GpsModel('6.22 Km/h', 4, 100, '2019-10-12 05:19:39', '39.75 km', '', -6.2663116, 106.78325));
    _gpsList.add(new GpsModel('16.16 Km/h', 337, 100, '2019-10-12 05:19:59', '39.84 km', '', -6.2655115, 106.78314));
    _gpsList.add(new GpsModel('9.66 Km/h', 330, 100, '2019-10-12 05:20:19', '39.9 km', '2 hours 23 minutes', -6.265128, 106.782845));
    _gpsList.add(new GpsModel('0.09 Km/h', 170, 100, '2019-10-12 07:43:26', '40.11 km', '', -6.2670665, 106.783));
    _gpsList.add(new GpsModel('5.86 Km/h', 187, 100, '2019-10-12 07:43:46', '40.15 km', '', -6.267355, 106.78295));
    _gpsList.add(new GpsModel('1.08 Km/h', 99, 100, '2019-10-12 07:45:45', '40.18 km', '', -6.267637, 106.783104));
    _gpsList.add(new GpsModel('7.82 Km/h', 0, 100, '2019-10-12 07:46:05', '40.23 km', '', -6.2675633, 106.78349));
    _gpsList.add(new GpsModel('20.43 Km/h', 0, 100, '2019-10-12 07:46:25', '40.34 km', '', -6.2665467, 106.78358));
    _gpsList.add(new GpsModel('4.11 Km/h', 359, 100, '2019-10-12 07:47:24', '40.41 km', '', -6.2659435, 106.78352));
    _gpsList.add(new GpsModel('12.41 Km/h', 356, 100, '2019-10-12 07:47:36', '40.45 km', '', -6.265577, 106.783455));
    _gpsList.add(new GpsModel('2.99 Km/h', 358, 100, '2019-10-12 07:48:24', '40.49 km', '', -6.26522, 106.78342));
    _gpsList.add(new GpsModel('2.39 Km/h', 1, 100, '2019-10-12 07:49:23', '40.53 km', '', -6.2648735, 106.783356));
    _gpsList.add(new GpsModel('15.61 Km/h', 3, 100, '2019-10-12 07:49:43', '40.61 km', '', -6.2640934, 106.78336));
    _gpsList.add(new GpsModel('31.49 Km/h', 67, 100, '2019-10-12 07:50:03', '40.79 km', '', -6.2631683, 106.78464));
    _gpsList.add(new GpsModel('32.41 Km/h', 103, 100, '2019-10-12 07:50:23', '40.97 km', '', -6.263, 106.78626));
    _gpsList.add(new GpsModel('31.24 Km/h', 103, 100, '2019-10-12 07:50:43', '41.14 km', '', -6.26335, 106.78779));
    _gpsList.add(new GpsModel('10.75 Km/h', 210, 100, '2019-10-12 07:51:03', '41.2 km', '', -6.2635765, 106.78828));
    _gpsList.add(new GpsModel('3.11 Km/h', 164, 100, '2019-10-12 07:51:23', '41.22 km', '', -6.2637315, 106.78829));
    _gpsList.add(new GpsModel('2.68 Km/h', 133, 100, '2019-10-12 07:51:42', '41.23 km', '2 hours 15 minutes', -6.2636666, 106.7884));
    _gpsList.add(new GpsModel('0.01 Km/h', 25, 100, '2019-10-12 10:05:26', '41.24 km', '', -6.2637467, 106.78833));
    _gpsList.add(new GpsModel('4.94 Km/h', 104, 100, '2019-10-12 10:06:25', '41.33 km', '', -6.263692, 106.78906));
    _gpsList.add(new GpsModel('24.97 Km/h', 91, 100, '2019-10-12 10:06:45', '41.46 km', '', -6.263885, 106.7903));
    _gpsList.add(new GpsModel('22.89 Km/h', 96, 100, '2019-10-12 10:07:05', '41.59 km', '', -6.26392, 106.79145));
    _gpsList.add(new GpsModel('20.25 Km/h', 128, 100, '2019-10-12 10:07:25', '41.7 km', '', -6.2640433, 106.79246));
    _gpsList.add(new GpsModel('14.47 Km/h', 103, 100, '2019-10-12 10:07:45', '41.78 km', '', -6.264147, 106.79318));
    _gpsList.add(new GpsModel('19.29 Km/h', 101, 100, '2019-10-12 10:08:05', '41.89 km', '', -6.2643065, 106.794136));
    _gpsList.add(new GpsModel('13.84 Km/h', 10, 100, '2019-10-12 10:08:24', '41.96 km', '', -6.263692, 106.79437));
    _gpsList.add(new GpsModel('14.36 Km/h', 106, 100, '2019-10-12 10:08:44', '42.04 km', '', -6.26374, 106.79509));
    _gpsList.add(new GpsModel('2.6 Km/h', 115, 100, '2019-10-12 10:09:53', '42.09 km', '', -6.263857, 106.795525));
    _gpsList.add(new GpsModel('4.43 Km/h', 103, 100, '2019-10-12 10:11:03', '42.18 km', '', -6.26394, 106.7963));
    _gpsList.add(new GpsModel('1.43 Km/h', 82, 100, '2019-10-12 10:13:22', '42.24 km', '', -6.2639217, 106.7968));
    _gpsList.add(new GpsModel('0.69 Km/h', 55, 100, '2019-10-12 10:14:51', '42.25 km', '', -6.263883, 106.79695));
    _gpsList.add(new GpsModel('0.64 Km/h', 81, 100, '2019-10-12 10:16:01', '42.27 km', '', -6.263857, 106.79706));
    _gpsList.add(new GpsModel('22.1 Km/h', 334, 100, '2019-10-12 10:16:21', '42.39 km', '', -6.262797, 106.79675));
    _gpsList.add(new GpsModel('28.33 Km/h', 358, 100, '2019-10-12 10:16:41', '42.55 km', '', -6.2614, 106.79652));
    _gpsList.add(new GpsModel('14.99 Km/h', 4, 100, '2019-10-12 10:17:01', '42.63 km', '', -6.2606516, 106.79655));
    _gpsList.add(new GpsModel('12.89 Km/h', 0, 100, '2019-10-12 10:17:21', '42.7 km', '', -6.2600083, 106.79658));
    _gpsList.add(new GpsModel('28.98 Km/h', 6, 100, '2019-10-12 10:17:41', '42.86 km', '', -6.258567, 106.79672));
    _gpsList.add(new GpsModel('20.05 Km/h', 5, 100, '2019-10-12 10:18:20', '43.08 km', '', -6.2566266, 106.79695));
    _gpsList.add(new GpsModel('19.67 Km/h', 6, 100, '2019-10-12 10:18:40', '43.19 km', '', -6.2556567, 106.79711));
    _gpsList.add(new GpsModel('8.17 Km/h', 1, 100, '2019-10-12 10:19:00', '43.23 km', '', -6.2552633, 106.79722));
    _gpsList.add(new GpsModel('19.86 Km/h', 90, 100, '2019-10-12 10:19:20', '43.34 km', '', -6.254958, 106.79817));
    _gpsList.add(new GpsModel('35.13 Km/h', 87, 100, '2019-10-12 10:19:40', '43.54 km', '', -6.2548184, 106.79993));
    _gpsList.add(new GpsModel('34.33 Km/h', 87, 100, '2019-10-12 10:19:49', '43.62 km', '', -6.2547717, 106.800705));
    _gpsList.add(new GpsModel('11.62 Km/h', 163, 100, '2019-10-12 10:20:19', '43.72 km', '', -6.2548733, 106.801575));
    _gpsList.add(new GpsModel('1.41 Km/h', 112, 100, '2019-10-12 10:20:59', '43.74 km', '', -6.2547917, 106.80169));
    _gpsList.add(new GpsModel('2.53 Km/h', 112, 100, '2019-10-12 10:21:19', '43.75 km', '', -6.2546935, 106.80177));
    _gpsList.add(new GpsModel('24.2 Km/h', 88, 100, '2019-10-12 10:21:39', '43.89 km', '', -6.2546635, 106.802986));
    _gpsList.add(new GpsModel('18.83 Km/h', 349, 100, '2019-10-12 10:21:59', '43.99 km', '', -6.2543983, 106.803894));
    _gpsList.add(new GpsModel('11.73 Km/h', 122, 100, '2019-10-12 10:22:19', '44.06 km', '', -6.254235, 106.80446));
    _gpsList.add(new GpsModel('16.33 Km/h', 4, 100, '2019-10-12 10:22:38', '44.14 km', '', -6.2540617, 106.80522));
    _gpsList.add(new GpsModel('31.91 Km/h', 24, 100, '2019-10-12 10:22:58', '44.32 km', '', -6.2526135, 106.80589));
    _gpsList.add(new GpsModel('32.53 Km/h', 26, 100, '2019-10-12 10:23:18', '44.5 km', '', -6.251147, 106.806595));
    _gpsList.add(new GpsModel('34.63 Km/h', 52, 100, '2019-10-12 10:23:38', '44.69 km', '', -6.2499084, 106.80781));
    _gpsList.add(new GpsModel('13.15 Km/h', 84, 100, '2019-10-12 10:23:58', '44.76 km', '', -6.249457, 106.80829));
    _gpsList.add(new GpsModel('28.19 Km/h', 114, 100, '2019-10-12 10:24:18', '44.92 km', '', -6.2500267, 106.809586));
    _gpsList.add(new GpsModel('27.1 Km/h', 222, 100, '2019-10-12 10:24:38', '45.07 km', '', -6.251362, 106.80936));
    _gpsList.add(new GpsModel('41.49 Km/h', 219, 100, '2019-10-12 10:24:46', '45.16 km', '', -6.25204, 106.80888));
    _gpsList.add(new GpsModel('20.84 Km/h', 193, 100, '2019-10-12 10:24:57', '45.23 km', '', -6.252565, 106.80865));
    _gpsList.add(new GpsModel('19.08 Km/h', 191, 100, '2019-10-12 10:25:17', '45.33 km', '', -6.2534485, 106.80829));
    _gpsList.add(new GpsModel('15.55 Km/h', 175, 100, '2019-10-12 10:25:37', '45.42 km', '', -6.2542214, 106.80821));
    _gpsList.add(new GpsModel('2.87 Km/h', 84, 100, '2019-10-12 10:27:36', '45.52 km', '', -6.2550035, 106.80855));
    _gpsList.add(new GpsModel('26.62 Km/h', 93, 100, '2019-10-12 10:27:56', '45.66 km', '', -6.2551465, 106.80988));
    _gpsList.add(new GpsModel('18.71 Km/h', 89, 100, '2019-10-12 10:28:16', '45.77 km', '', -6.2551765, 106.81082));
    _gpsList.add(new GpsModel('18.95 Km/h', 135, 100, '2019-10-12 10:28:36', '45.87 km', '', -6.2554564, 106.81173));
    _gpsList.add(new GpsModel('7.97 Km/h', 92, 100, '2019-10-12 10:28:56', '45.92 km', '', -6.2556314, 106.81209));
    _gpsList.add(new GpsModel('5.28 Km/h', 88, 100, '2019-10-12 10:29:16', '45.95 km', '', -6.255622, 106.812355));
    _gpsList.add(new GpsModel('12.59 Km/h', 73, 100, '2019-10-12 10:29:35', '46.01 km', '', -6.255535, 106.81295));
    _gpsList.add(new GpsModel('21.33 Km/h', 86, 100, '2019-10-12 10:29:44', '46.07 km', '', -6.2554865, 106.81343));
    _gpsList.add(new GpsModel('22.85 Km/h', 84, 100, '2019-10-12 10:29:55', '46.14 km', '', -6.2554398, 106.81406));
    _gpsList.add(new GpsModel('3.88 Km/h', 119, 100, '2019-10-12 10:30:55', '46.2 km', '', -6.2554717, 106.814644));
    _gpsList.add(new GpsModel('1.03 Km/h', 175, 100, '2019-10-12 10:32:54', '46.23 km', '', -6.25577, 106.81471));
    _gpsList.add(new GpsModel('4.66 Km/h', 171, 100, '2019-10-12 10:33:14', '46.26 km', '', -6.255995, 106.81477));
    _gpsList.add(new GpsModel('4.06 Km/h', 173, 100, '2019-10-12 10:33:34', '46.28 km', '', -6.256195, 106.814804));
    _gpsList.add(new GpsModel('4.81 Km/h', 177, 100, '2019-10-12 10:33:54', '46.31 km', '', -6.2564335, 106.814835));
    _gpsList.add(new GpsModel('1.16 Km/h', 176, 100, '2019-10-12 10:34:42', '46.32 km', '', -6.256573, 106.81483));
    _gpsList.add(new GpsModel('5.54 Km/h', 274, 100, '2019-10-12 10:34:53', '46.34 km', '', -6.256635, 106.81469));
    _gpsList.add(new GpsModel('0.09 Km/h', 295, 100, '2019-10-12 10:39:40', '46.35 km', '44 minutes', -6.2567015, 106.81468));
    _gpsList.add(new GpsModel('0.08 Km/h', 180, 100, '2019-10-12 11:24:22', '46.41 km', '', -6.2571735, 106.814896));
    _gpsList.add(new GpsModel('2 Km/h', 183, 100, '2019-10-12 11:24:40', '46.42 km', '', -6.2572618, 106.81488));
    _gpsList.add(new GpsModel('0.28 Km/h', 184, 100, '2019-10-12 11:26:19', '46.42 km', '', -6.2572985, 106.81494));
    _gpsList.add(new GpsModel('1.16 Km/h', 244, 100, '2019-10-12 11:29:37', '46.49 km', '', -6.257682, 106.81451));
    _gpsList.add(new GpsModel('8.62 Km/h', 250, 100, '2019-10-12 11:29:57', '46.54 km', '', -6.257847, 106.81411));
    _gpsList.add(new GpsModel('8.68 Km/h', 246, 100, '2019-10-12 11:30:17', '46.58 km', '', -6.25802, 106.81371));
    _gpsList.add(new GpsModel('5.89 Km/h', 356, 100, '2019-10-12 11:30:37', '46.62 km', '', -6.2579618, 106.81342));
    _gpsList.add(new GpsModel('8.15 Km/h', 352, 100, '2019-10-12 11:30:57', '46.66 km', '', -6.25756, 106.813354));
    _gpsList.add(new GpsModel('13.83 Km/h', 355, 100, '2019-10-12 11:31:17', '46.74 km', '', -6.256873, 106.81328));
    _gpsList.add(new GpsModel('6.14 Km/h', 263, 100, '2019-10-12 11:31:37', '46.77 km', '', -6.256708, 106.81302));
    _gpsList.add(new GpsModel('3.14 Km/h', 10, 100, '2019-10-12 11:32:36', '46.82 km', '', -6.2563915, 106.81268));
    _gpsList.add(new GpsModel('9.48 Km/h', 0, 100, '2019-10-12 11:32:56', '46.88 km', '', -6.2559185, 106.81266));
    _gpsList.add(new GpsModel('6.67 Km/h', 259, 100, '2019-10-12 11:33:16', '46.91 km', '', -6.2557516, 106.81237));
    _gpsList.add(new GpsModel('3.58 Km/h', 292, 100, '2019-10-12 11:34:28', '46.99 km', '', -6.2555985, 106.81174));
    _gpsList.add(new GpsModel('0.01 Km/h', 292, 100, '2019-10-12 11:39:26', '46.99 km', '50 minutes', -6.255592, 106.81174));
    _gpsList.add(new GpsModel('0.04 Km/h', 279, 100, '2019-10-12 12:29:26', '47.02 km', '', -6.2554216, 106.81146));
    _gpsList.add(new GpsModel('3.74 Km/h', 268, 100, '2019-10-12 12:30:06', '47.06 km', '', -6.255315, 106.8111));
    _gpsList.add(new GpsModel('6.4 Km/h', 271, 100, '2019-10-12 12:31:06', '47.17 km', '', -6.2552967, 106.810135));
    _gpsList.add(new GpsModel('8.49 Km/h', 268, 100, '2019-10-12 12:31:25', '47.22 km', '', -6.2552814, 106.80973));
    _gpsList.add(new GpsModel('13.73 Km/h', 274, 100, '2019-10-12 12:31:45', '47.29 km', '', -6.255272, 106.80904));
    _gpsList.add(new GpsModel('5.97 Km/h', 268, 100, '2019-10-12 12:32:05', '47.33 km', '', -6.2552586, 106.80874));
    _gpsList.add(new GpsModel('1.02 Km/h', 281, 100, '2019-10-12 12:33:44', '47.35 km', '', -6.25518, 106.8085));
    _gpsList.add(new GpsModel('21.8 Km/h', 290, 100, '2019-10-12 12:34:03', '47.47 km', '', -6.25486, 106.80751));
    _gpsList.add(new GpsModel('40.64 Km/h', 290, 100, '2019-10-12 12:34:04', '47.48 km', '', -6.254812, 106.80742));
    _gpsList.add(new GpsModel('18.43 Km/h', 256, 100, '2019-10-12 12:34:44', '47.68 km', '', -6.254707, 106.80557));
    _gpsList.add(new GpsModel('21.95 Km/h', 266, 100, '2019-10-12 12:35:04', '47.81 km', '', -6.25462, 106.80447));
    _gpsList.add(new GpsModel('13.33 Km/h', 272, 100, '2019-10-12 12:35:24', '47.88 km', '', -6.2546215, 106.8038));
    _gpsList.add(new GpsModel('23.93 Km/h', 267, 100, '2019-10-12 12:35:44', '48.01 km', '', -6.254705, 106.8026));
    _gpsList.add(new GpsModel('23.11 Km/h', 300, 100, '2019-10-12 12:36:03', '48.14 km', '', -6.2544365, 106.80153));
    _gpsList.add(new GpsModel('24.81 Km/h', 357, 100, '2019-10-12 12:36:23', '48.27 km', '', -6.2532115, 106.80134));
    _gpsList.add(new GpsModel('18.63 Km/h', 290, 100, '2019-10-12 12:36:43', '48.38 km', '', -6.2525716, 106.80066));
    _gpsList.add(new GpsModel('25.93 Km/h', 256, 100, '2019-10-12 12:37:03', '48.52 km', '', -6.2528167, 106.79938));
    _gpsList.add(new GpsModel('22.73 Km/h', 258, 100, '2019-10-12 12:37:23', '48.65 km', '', -6.2530184, 106.798256));
    _gpsList.add(new GpsModel('4.61 Km/h', 290, 100, '2019-10-12 12:38:42', '48.75 km', '', -6.2530365, 106.79734));
    _gpsList.add(new GpsModel('33.94 Km/h', 5, 100, '2019-10-12 12:39:01', '48.93 km', '', -6.2514315, 106.79748));
    _gpsList.add(new GpsModel('41.29 Km/h', 4, 100, '2019-10-12 12:39:02', '48.94 km', '', -6.2513285, 106.797485));
    _gpsList.add(new GpsModel('24.46 Km/h', 14, 100, '2019-10-12 12:39:22', '49.08 km', '', -6.2501082, 106.797554));
    _gpsList.add(new GpsModel('20.27 Km/h', 269, 100, '2019-10-12 12:39:42', '49.19 km', '', -6.2497134, 106.796616));
    _gpsList.add(new GpsModel('16.26 Km/h', 9, 100, '2019-10-12 12:40:02', '49.28 km', '', -6.2490835, 106.7961));
    _gpsList.add(new GpsModel('27.28 Km/h', 324, 100, '2019-10-12 12:40:22', '49.43 km', '', -6.24812, 106.79513));
    _gpsList.add(new GpsModel('21.97 Km/h', 356, 100, '2019-10-12 12:40:41', '49.55 km', '', -6.2471333, 106.79479));
    _gpsList.add(new GpsModel('6.62 Km/h', 337, 100, '2019-10-12 12:41:21', '49.62 km', '', -6.2464867, 106.79465));
    _gpsList.add(new GpsModel('2.36 Km/h', 324, 100, '2019-10-12 12:43:40', '49.71 km', '', -6.2458067, 106.79419));
    _gpsList.add(new GpsModel('14.45 Km/h', 324, 100, '2019-10-12 12:43:59', '49.79 km', '', -6.24521, 106.79385));
    _gpsList.add(new GpsModel('12.06 Km/h', 325, 100, '2019-10-12 12:44:00', '49.79 km', '', -6.2451816, 106.79384));
    _gpsList.add(new GpsModel('23.92 Km/h', 339, 100, '2019-10-12 12:44:20', '49.92 km', '', -6.244135, 106.79326));
    _gpsList.add(new GpsModel('5.49 Km/h', 349, 100, '2019-10-12 12:44:40', '49.95 km', '', -6.2438664, 106.793205));
    _gpsList.add(new GpsModel('6.91 Km/h', 353, 100, '2019-10-12 12:45:19', '50.03 km', '', -6.2432084, 106.79306));
    _gpsList.add(new GpsModel('13.2 Km/h', 351, 100, '2019-10-12 12:45:39', '50.1 km', '', -6.242553, 106.792984));
    _gpsList.add(new GpsModel('2.07 Km/h', 312, 100, '2019-10-12 12:47:58', '50.18 km', '', -6.241872, 106.792755));
    _gpsList.add(new GpsModel('21.36 Km/h', 251, 100, '2019-10-12 12:48:18', '50.3 km', '', -6.24204, 106.791695));
    _gpsList.add(new GpsModel('1.18 Km/h', 257, 100, '2019-10-12 12:48:57', '50.31 km', '', -6.242025, 106.79181));
    _gpsList.add(new GpsModel('5.12 Km/h', 274, 100, '2019-10-12 12:49:18', '50.34 km', '', -6.242018, 106.79154));
    _gpsList.add(new GpsModel('30.45 Km/h', 277, 100, '2019-10-12 12:49:38', '50.51 km', '', -6.241842, 106.79002));
    _gpsList.add(new GpsModel('29.14 Km/h', 282, 100, '2019-10-12 12:49:57', '50.67 km', '', -6.2410083, 106.78891));
    _gpsList.add(new GpsModel('26.06 Km/h', 286, 100, '2019-10-12 12:50:17', '50.81 km', '', -6.240782, 106.78762));
    _gpsList.add(new GpsModel('15.11 Km/h', 319, 100, '2019-10-12 12:50:37', '50.89 km', '', -6.2402835, 106.78705));
    _gpsList.add(new GpsModel('27.65 Km/h', 312, 100, '2019-10-12 12:50:57', '51.05 km', '', -6.239538, 106.78588));
    _gpsList.add(new GpsModel('27.16 Km/h', 274, 100, '2019-10-12 12:51:17', '51.2 km', '', -6.23953, 106.784515));
    _gpsList.add(new GpsModel('23.81 Km/h', 295, 100, '2019-10-12 12:51:37', '51.33 km', '', -6.239218, 106.78336));
    _gpsList.add(new GpsModel('19.58 Km/h', 176, 100, '2019-10-12 12:51:57', '51.44 km', '', -6.2401667, 106.78312));
    _gpsList.add(new GpsModel('21.75 Km/h', 191, 100, '2019-10-12 12:52:16', '51.55 km', '', -6.241185, 106.78295));
    _gpsList.add(new GpsModel('21.82 Km/h', 184, 100, '2019-10-12 12:52:36', '51.68 km', '', -6.2422733, 106.78289));
    _gpsList.add(new GpsModel('15.89 Km/h', 142, 100, '2019-10-12 12:52:56', '51.76 km', '', -6.243067, 106.78288));
    _gpsList.add(new GpsModel('16.67 Km/h', 176, 100, '2019-10-12 12:53:16', '51.86 km', '', -6.2438865, 106.78273));
    _gpsList.add(new GpsModel('4.02 Km/h', 17, 100, '2019-10-12 12:53:36', '51.88 km', '', -6.2439165, 106.78293));
    _gpsList.add(new GpsModel('8.59 Km/h', 335, 100, '2019-10-12 12:53:55', '51.92 km', '', -6.243513, 106.78287));
    _gpsList.add(new GpsModel('13.18 Km/h', 333, 100, '2019-10-12 12:53:56', '51.93 km', '', -6.2434816, 106.78286));
    _gpsList.add(new GpsModel('3.03 Km/h', 340, 100, '2019-10-12 12:54:55', '51.98 km', '', -6.243058, 106.783));
    _gpsList.add(new GpsModel('6.84 Km/h', 19, 100, '2019-10-12 12:55:15', '52.02 km', '', -6.2427235, 106.78307));
    _gpsList.add(new GpsModel('2.31 Km/h', 68, 100, '2019-10-12 12:55:35', '52.03 km', '', -6.242615, 106.78311));
    _gpsList.add(new GpsModel('0.87 Km/h', 138, 100, '2019-10-12 12:55:55', '52.03 km', '', -6.2426467, 106.78314));
    _gpsList.add(new GpsModel('4.24 Km/h', 273, 100, '2019-10-12 12:56:15', '52.06 km', '2 hours ', -6.242855, 106.7831));
    _gpsList.add(new GpsModel('0.03 Km/h', 192, 100, '2019-10-12 14:56:42', '52.13 km', '', -6.243467, 106.78297));
    _gpsList.add(new GpsModel('8.04 Km/h', 197, 100, '2019-10-12 14:57:02', '52.17 km', '', -6.2438216, 106.78278));
    _gpsList.add(new GpsModel('4.16 Km/h', 177, 100, '2019-10-12 14:57:21', '52.19 km', '', -6.2440186, 106.78277));
    _gpsList.add(new GpsModel('3.56 Km/h', 201, 100, '2019-10-12 14:59:01', '52.29 km', '', -6.244808, 106.78236));
    _gpsList.add(new GpsModel('7.51 Km/h', 200, 100, '2019-10-12 14:59:21', '52.33 km', '', -6.245148, 106.7822));
    _gpsList.add(new GpsModel('4.44 Km/h', 190, 100, '2019-10-12 14:59:40', '52.36 km', '', -6.2453485, 106.782135));
    _gpsList.add(new GpsModel('4.44 Km/h', 195, 100, '2019-10-12 15:00:00', '52.38 km', '', -6.245547, 106.782036));
    _gpsList.add(new GpsModel('22.02 Km/h', 203, 100, '2019-10-12 15:00:08', '52.43 km', '', -6.245955, 106.78187));
    _gpsList.add(new GpsModel('25.54 Km/h', 196, 100, '2019-10-12 15:00:20', '52.52 km', '', -6.2466683, 106.78159));
    _gpsList.add(new GpsModel('20.9 Km/h', 187, 100, '2019-10-12 15:00:40', '52.63 km', '', -6.2476916, 106.78138));
    _gpsList.add(new GpsModel('30.5 Km/h', 170, 100, '2019-10-12 15:01:00', '52.8 km', '', -6.249215, 106.78134));
    _gpsList.add(new GpsModel('19.02 Km/h', 173, 100, '2019-10-12 15:01:20', '52.91 km', '', -6.2501535, 106.78149));
    _gpsList.add(new GpsModel('16.12 Km/h', 176, 100, '2019-10-12 15:01:40', '53 km', '', -6.250953, 106.78159));
    _gpsList.add(new GpsModel('22.51 Km/h', 176, 100, '2019-10-12 15:01:59', '53.12 km', '', -6.2520185, 106.78167));
    _gpsList.add(new GpsModel('23.63 Km/h', 178, 100, '2019-10-12 15:02:19', '53.25 km', '', -6.253198, 106.781715));
    _gpsList.add(new GpsModel('10.11 Km/h', 179, 100, '2019-10-12 15:02:59', '53.36 km', '', -6.2542086, 106.78171));
    _gpsList.add(new GpsModel('6 Km/h', 175, 100, '2019-10-12 15:03:19', '53.39 km', '', -6.2545085, 106.781715));
    _gpsList.add(new GpsModel('9.4 Km/h', 178, 100, '2019-10-12 15:03:39', '53.44 km', '', -6.254978, 106.781715));
    _gpsList.add(new GpsModel('30.99 Km/h', 179, 100, '2019-10-12 15:03:59', '53.62 km', '', -6.2565265, 106.78172));
    _gpsList.add(new GpsModel('41.82 Km/h', 178, 100, '2019-10-12 15:04:18', '53.84 km', '', -6.2585115, 106.78174));
    _gpsList.add(new GpsModel('42.16 Km/h', 170, 100, '2019-10-12 15:04:38', '54.07 km', '', -6.2606134, 106.78188));
    _gpsList.add(new GpsModel('32.35 Km/h', 121, 100, '2019-10-12 15:04:58', '54.25 km', '', -6.262, 106.782715));
    _gpsList.add(new GpsModel('21.69 Km/h', 126, 100, '2019-10-12 15:05:06', '54.3 km', '', -6.262265, 106.78306));
    _gpsList.add(new GpsModel('29.06 Km/h', 160, 100, '2019-10-12 15:05:18', '54.4 km', '', -6.2629733, 106.78357));
    _gpsList.add(new GpsModel('20.2 Km/h', 54, 100, '2019-10-12 15:05:38', '54.51 km', '', -6.2631483, 106.78457));
    _gpsList.add(new GpsModel('32.95 Km/h', 108, 100, '2019-10-12 15:05:58', '54.69 km', '', -6.2630067, 106.78622));
    _gpsList.add(new GpsModel('29.89 Km/h', 105, 100, '2019-10-12 15:06:18', '54.86 km', '', -6.263358, 106.78768));
    _gpsList.add(new GpsModel('12.87 Km/h', 177, 100, '2019-10-12 15:06:37', '54.93 km', '', -6.26356, 106.78826));
    _gpsList.add(new GpsModel('3.63 Km/h', 181, 100, '2019-10-12 15:06:57', '54.95 km', '13 hours 29 minutes', -6.26374, 106.78828));

  }

  // this function is to draw custom marker
  BitmapDescriptor _markerDirection;
  BitmapDescriptor _markerStop;
  void _setSourceAndDestinationIcons() async {
    _markerDirection = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(devicePixelRatio: 2.5),
        'assets/images/direction.png');
    _markerStop = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(devicePixelRatio: 2.5), 'assets/images/stop.png');
  }

  /* start additional function for camera update
  - we get this function from the internet
  - if we don't use this function, the camera will not work properly (Zoom to marker sometimes not work)
  */
  void _check(CameraUpdate u, GoogleMapController c) async {
    c.moveCamera(u);
    _controller.moveCamera(u);
    LatLngBounds l1=await c.getVisibleRegion();
    LatLngBounds l2=await c.getVisibleRegion();

    if(l1.southwest.latitude==-90 ||l2.southwest.latitude==-90)
      _check(u, c);
  }

  LatLngBounds _boundsFromLatLngList(List<LatLng> list) {
    assert(list.isNotEmpty);
    double x0, x1, y0, y1;
    for (LatLng latLng in list) {
      if (x0 == null) {
        x0 = x1 = latLng.latitude;
        y0 = y1 = latLng.longitude;
      } else {
        if (latLng.latitude > x1) x1 = latLng.latitude;
        if (latLng.latitude < x0) x0 = latLng.latitude;
        if (latLng.longitude > y1) y1 = latLng.longitude;
        if (latLng.longitude < y0) y0 = latLng.longitude;
      }
    }
    return LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
  }

  // when the Google Maps Camera is change, get the current position
  void _onGeoChanged(CameraPosition position) {
    _currentZoom = position.zoom;
  }

  String _formatDatetime(String date) {
    var dateTime = DateFormat('yyyy-MM-dd HH:mm:ss').parse(date, true);
    var newDate = DateFormat('yyyy-MM-dd HH:mm:ss').format(dateTime.toLocal());
    return newDate;
  }

  @override
  void initState() {
    _addDummyGps();
    _setSourceAndDestinationIcons();
    super.initState();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _timerDummy?.cancel();
    super.dispose();
  }

  GoogleMap _buildGoogleMap() {
    return GoogleMap(
        mapType: MapType.normal,
        trafficEnabled: false,
        compassEnabled: true,
        rotateGesturesEnabled: true,
        scrollGesturesEnabled: true,
        tiltGesturesEnabled: true,
        zoomControlsEnabled: false,
        zoomGesturesEnabled: true,
        myLocationButtonEnabled: false,
        myLocationEnabled: false,
        mapToolbarEnabled: true,
        markers: Set<Marker>.of(_allMarker.values),
        polylines: Set<Polyline>.of(_mapPolylines.values),
        initialCameraPosition: CameraPosition(
          target: _initialPosition,
          zoom: 4,
        ),
        onCameraMove: _onGeoChanged,
        onCameraIdle: (){
          if(_isBound==false && _doneListing==true) {
            _isBound = true;
            CameraUpdate u2=CameraUpdate.newLatLngBounds(_boundsFromLatLngList(_latlng), 50);
            this._controller.moveCamera(u2).then((void v){
              _check(u2,this._controller);
            });
          }
        },
        onMapCreated: (GoogleMapController controller) {
          _controller = controller;

          // we use timer for this demo
          // in the real application, get all marker from database
          // Get the marker from API and add the marker here
          _timerDummy = Timer(Duration(seconds: 1), () {
            setState(() {
              _mapLoading = false;

              // add all marker here
              for (int i = 0; i < _gpsList.length; i++) {
                LatLng position = LatLng(_gpsList[i].getLat,
                    _gpsList[i].getLong);
                _latlng.add(position);

                BitmapDescriptor markerIcon;
                Offset markerAnchor = Offset(0.5, 0.5);
                if (_gpsList[i].getStopTime == '') {
                  markerIcon = _markerDirection;
                } else {
                  markerIcon = _markerStop;
                }

                double angle = 0;
                if (_gpsList[i].getStopTime == '') {
                  angle = _gpsList[i].getDirection.toDouble();
                }

                if (i == 0) {
                  _speed = _gpsList[i].getSpeed;
                  _mileage = _gpsList[i].getMileage;
                  _gpsDate = _gpsList[i].getGpsDate;
                  _stopTime = _gpsList[i].getStopTime;
                }

                _allMarker[MarkerId(i.toString())] = Marker(
                  markerId: MarkerId(i.toString()),
                  visible: (i == 0) ? true : false,
                  flat: (_gpsList[i].getStopTime == '')
                      ? true
                      : false,
                  position: position,
                  anchor: markerAnchor,
                  onTap: () {
                    _speed = _gpsList[i].getSpeed;
                    _mileage = _gpsList[i].getMileage;
                    _gpsDate = _gpsList[i].getGpsDate;
                    _stopTime = _gpsList[i].getStopTime;

                    setState(() {
                      _infoDetail = true;
                    });
                  },
                  rotation: angle,
                  icon: markerIcon,
                );
                if(i==_gpsList.length-1){
                  _doneListing = true;
                }
              }

              // draw all polylines here
              final PolylineId polylineId = PolylineId('track');
              final Polyline polyline = Polyline(
                polylineId: polylineId,
                visible: true,
                width: 2,
                points: _latlng,
                color: MAPS_IMAGES_COLOR,
              );
              _mapPolylines[polylineId] = polyline;

              // zoom to all track polylines
              if(_isBound==false && _doneListing==true) {
                _isBound = true;
                CameraUpdate u2=CameraUpdate.newLatLngBounds(_boundsFromLatLngList(_latlng), 50);
                this._controller.moveCamera(u2).then((void v){
                  _check(u2,this._controller);
                });
              }
            });
          });
        },
        onTap: (position) {
          setState(() {
            _infoDetail = false;
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            'HISTORY ( ' + widget.date.toString() + ' )',
            style: TextStyle(
              fontSize: 16,
            ),
          ),
          backgroundColor: PRIMARY_COLOR,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Expanded(
              child: Stack(
                children: <Widget>[
                  _buildGoogleMap(),
                  Positioned.fill(
                    top: 12,
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12, 5, 12, 5),
                        color: Color(0x950a4349),
                        child: Wrap(
                          children: <Widget>[
                            Icon(
                              DEV_ICON1,
                              color: Colors.white,
                              size: 16,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              DEV_NAME1 + ' | ' + SN1,
                              style: TextStyle(color: Colors.white),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 40,
                    left: 12,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _showMarker = (_showMarker) ? false : true;

                          for (int a = 0; a < _allMarker.length; a++) {
                            if (a != _valProgress) {
                              _allMarker[MarkerId(a.toString())] =
                                  _allMarker[MarkerId(a.toString())].copyWith(
                                    visibleParam: _showMarker,
                                  );
                            }
                          }
                        });
                      },
                      child: Container(
                        padding: EdgeInsets.all(5),
                        width: 36,
                        height: 36,
                        color: Color(0x99FFFFFF),
                        child: Icon(
                          (_showMarker)
                              ? Icons.location_on
                              : Icons.location_off,
                          color: MAPS_IMAGES_COLOR,
                          size: 26,
                        ),
                      ),
                    ),
                  ),
                  Positioned.fill(
                    bottom: 14,
                    child: AnimatedOpacity(
                      opacity: _infoDetail ? 1.0 : 0.0,
                      duration: Duration(milliseconds: 400),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Wrap(children: <Widget>[
                          Card(
                            child: Container(
                              padding: EdgeInsets.fromLTRB(8, 5, 8, 5),
                              color: Colors.white,
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: <Widget>[
                                  Wrap(
                                    children: <Widget>[
                                      Image.asset(
                                        'assets/images/speed.png',
                                        height: 14,
                                        color: MAPS_IMAGES_COLOR,
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        _speed,
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 1),
                                  Wrap(
                                    children: <Widget>[
                                      Icon(
                                        Icons.timeline,
                                        size: 13,
                                        color: MAPS_IMAGES_COLOR,
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        'mileage : '+_mileage,
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 1),
                                  Visibility(
                                    visible:
                                    (_stopTime == '') ? false : true,
                                    child: Wrap(
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/images/stop.png',
                                          height: 13,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          _stopTime,
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 1),
                                  Wrap(
                                    children: <Widget>[
                                      Icon(
                                        Icons.access_time,
                                        size: 13,
                                        color: MAPS_IMAGES_COLOR,
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        (_gpsDate == '')
                                            ? ''
                                            : _formatDatetime(_gpsDate),
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                        ]),
                      ),
                    ),
                  ),
                  (_mapLoading)?Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Colors.grey[100],
                    child: Center(
                      child: CircularProgressIndicator(),
                    ),
                  ):Container(),
                ],
              ),
            ),
            Container(
                margin: EdgeInsets.fromLTRB(12, 12, 12, 12),
                child: Row(
                  children: <Widget>[
                    GestureDetector(
                        onTap: () {
                          if(_playHistory){
                            if(_timer!=null){
                              _timer.cancel();
                            }
                          } else {
                            _startTimer();
                          }
                          setState(() {
                            _playHistory = (_playHistory) ? false : true;
                          });
                        },
                        child: Icon(
                          (_playHistory)
                              ? Icons.pause_circle_filled
                              : Icons.play_circle_filled,
                          color: MAPS_IMAGES_COLOR,
                          size: 40,
                        )),
                    SizedBox(
                      width: 12,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Progress',
                          style: TextStyle(fontSize: 14, color: MAPS_IMAGES_COLOR),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          'Speed',
                          style: TextStyle(fontSize: 14, color: MAPS_IMAGES_COLOR),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            height: 20,
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                activeTrackColor: MAPS_IMAGES_COLOR,
                                inactiveTrackColor:
                                MAPS_IMAGES_COLOR.withAlpha(150),
                                trackHeight: 1,
                                thumbColor: MAPS_IMAGES_COLOR,
                                thumbShape: RoundSliderThumbShape(
                                    enabledThumbRadius: 6),
                                overlayColor: MAPS_IMAGES_COLOR.withAlpha(32),
                              ),
                              child: Slider(
                                value: _valProgress,
                                min: 0,
                                max: _gpsList.length.toDouble() - 1,
                                divisions: (_gpsList.length - 1)==0?1:_gpsList.length - 1,
                                onChanged: (newValue) {
                                  if (_showMarker == false) {
                                    _allMarker[MarkerId(_valProgress
                                        .round()
                                        .toString())] = _allMarker[
                                    MarkerId(_valProgress
                                        .round()
                                        .toString())]
                                        .copyWith(
                                      visibleParam: false,
                                    );
                                  }
                                  _changeSliderProgress(newValue);
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Container(
                            height: 20,
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                activeTrackColor: MAPS_IMAGES_COLOR,
                                inactiveTrackColor:
                                MAPS_IMAGES_COLOR.withAlpha(150),
                                trackHeight: 1,
                                thumbColor: MAPS_IMAGES_COLOR,
                                thumbShape: RoundSliderThumbShape(
                                    enabledThumbRadius: 6),
                                overlayColor: MAPS_IMAGES_COLOR.withAlpha(32),
                              ),
                              child: Slider(
                                value: _valSpeed,
                                min: 1,
                                max: 12,
                                divisions: 11,
                                onChanged: (newValue) {
                                  setState(() {
                                    _valSpeed = newValue.round().toDouble();
                                    if(_timer!=null){
                                      _timer.cancel();
                                    }
                                    if(_playHistory) {
                                      _startTimer();
                                    }
                                  });
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ))
          ],
        )
    );
  }
}
