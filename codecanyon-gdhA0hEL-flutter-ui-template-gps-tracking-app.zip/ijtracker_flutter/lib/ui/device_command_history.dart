/*
This is device command history page
add shimmer loading to makes the loading more beautiful
add shimmer_loading.dart to this pages in folder reuseable

install plugin in pubspec.yaml
- shimmer_loading => to add beautiful loading (https://pub.dev/packages/shimmer)
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:ijtrackerflutter/config/constants.dart' show PRIMARY_COLOR;
import 'package:ijtrackerflutter/ui/reuseable/shimmer_loading.dart';

class DeviceCommandHistoryPage extends StatefulWidget {
  @override
  _DeviceCommandHistoryPageState createState() => _DeviceCommandHistoryPageState();
}

class _DeviceCommandHistoryPageState extends State<DeviceCommandHistoryPage> {
  bool _loading = true;
  Timer _timerDummy;

  @override
  void initState() {
    _timerDummy = Timer(Duration(seconds: 2), () {
      setState(() {
        _loading = false;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _timerDummy?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'DEVICE COMMAND HISTORY',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        backgroundColor: PRIMARY_COLOR,
      ),
      body: Container(
          child: (_loading == true)
              ? Center(child: ShimmerList())
              : ListView(
            children: <Widget>[
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Normal mode',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            'Success',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '12 Jul 2020, 14:39 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Power saving mode',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            'Success',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '12 Jul 2020, 12:39 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Upload interval',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '20 second',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '12 Jul 2020, 10:39 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Update center number',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '+62811888999',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '11 Jul 2020, 14:42 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Update center number',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '+62811888999',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '11 Jul 2020, 14:42 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Update center number',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '+62811888999',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '11 Jul 2020, 14:42 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Update center number',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '+62811888999',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '11 Jul 2020, 14:42 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Update center number',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '+62811888999',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '11 Jul 2020, 14:42 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              ),
              Container(
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            'Update center number',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                          child: Text(
                            '+62811888999',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 10),
                            child: Text(
                              '11 Jul 2020, 14:42 | Android',
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500]
                              ),
                              textAlign: TextAlign.left,
                            )
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ]
                  )
              )
            ],
          )),
    );
  }
}
