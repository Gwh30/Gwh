/*
This is notification page
add shimmer loading to makes the loading more beautiful
add shimmer_loading.dart to this pages in folder reuseable

install plugin in pubspec.yaml
- flutter_html => to add html tag to Text widget (https://pub.dev/packages/flutter_html)
- shimmer_loading => to add beautiful loading (https://pub.dev/packages/shimmer)
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:ijtrackerflutter/config/constants.dart';
import 'package:ijtrackerflutter/ui/reuseable/shimmer_loading.dart';

class NotificationPage extends StatefulWidget {
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  bool _loading = true;
  Timer _timerDummy;

  @override
  void initState() {
    // this timer function is just for demo, so after 2 second, the shimmer loading will disappear and show the content
    _timerDummy = Timer(Duration(seconds: 2), () {
      setState(() {
        _loading = false;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _timerDummy?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'NOTIFICATION',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        backgroundColor: PRIMARY_COLOR,
      ),
      body: Container(
          child: (_loading == true)
              ? Center(child: ShimmerList())
              : ListView(
                  children: <Widget>[
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number '+SN1+' is out of fence! <b>[Auto Geofence]</b>',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    ),
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number <b>'+SN1+'</b> is offline',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    ),
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number <b>'+SN1+'</b> has low power and already off! <b>[0%]</b>. Charge it immediately !',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    ),
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number <b>'+SN1+'</b> is <b>Expired</b> ! Please contact <b>iJTracker</b> to renew.',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    ),
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number <b>'+SN1+'</b> is <b>Expired</b> ! Please contact <b>iJTracker</b> to renew.',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    ),
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number <b>'+SN1+'</b> is <b>Expired</b> ! Please contact <b>iJTracker</b> to renew.',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    ),
                    Container(
                        color: Colors.white,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                child: Html(
                                  data: 'Your GPS <b>'+DEV_NAME1+'</b> with Serial Number <b>'+SN1+'</b> is <b>Expired</b> ! Please contact <b>iJTracker</b> to renew.',
                                  defaultTextStyle: TextStyle(fontSize: 16),
                                ),
                              ),
                              Container(
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                  child: Text(
                                    '28 Jul 2020, 10:00',
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[500]
                                    ),
                                    textAlign: TextAlign.left,
                                  )
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ]
                        )
                    )
                  ],
                )),
    );
  }
}
