/*
This is set device page
this pages is used to change your default device
add shimmer loading to makes the loading more beautiful
add shimmer_loading.dart to this pages in folder reuseable

At GestureDetector Widget add attribute below
behavior: HitTestBehavior.translucent
With this, you can hit all space on GestureDetector
If you don't use above attribute, you still can direct to another pages when you click right on the images or text

install plugin in pubspec.yaml
- fluttertoast => to show toast (https://pub.dev/packages/fluttertoast)
- shimmer_loading => to add beautiful loading (https://pub.dev/packages/shimmer)
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:ijtrackerflutter/config/constants.dart';
import 'package:ijtrackerflutter/ui/add_device.dart';
import 'package:ijtrackerflutter/ui/reuseable/shimmer_loading.dart';

class SetDevicePage extends StatefulWidget {
  @override
  _SetDevicePageState createState() => _SetDevicePageState();
}

class _SetDevicePageState extends State<SetDevicePage> {
  bool _loading = true;
  Timer _timerDummy;

  @override
  void initState() {
    // this timer function is just for demo, so after 2 second, the shimmer loading will disappear and show the content
    _timerDummy = Timer(Duration(seconds: 2), () {
      setState(() {
        _loading = false;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _timerDummy?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'SET DEVICE',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        backgroundColor: PRIMARY_COLOR,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Text(
                'Select to set device : ',
                style: TextStyle(color: Colors.grey[600]),
              )),
          Expanded(
            child: (_loading == true)
                ? Center(child: ShimmerList())
                : ListView(
                    children: <Widget>[
                      SizedBox(height: 20),
                      GestureDetector(
                        onTap: () {
                          Fluttertoast.showToast(
                              msg: 'Already set this device',
                              toastLength: Toast.LENGTH_LONG);
                        },
                        behavior: HitTestBehavior.translucent,
                        child: Container(
                          margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                          child: Column(
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Container(
                                    margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                                    child: Column(
                                      children: <Widget>[
                                        Icon(
                                          DEV_ICON1,
                                          color: MENU_IMAGES_COLOR,
                                          size: 28,
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Move',
                                          style: TextStyle(
                                              fontSize: 12, color: CHARCOAL),
                                        )
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                          DEV_NAME1+' ['+SN1+']',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                              color: CHARCOAL),
                                        ),
                                        Row(
                                          children: <Widget>[
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 3, 5, 0),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color:
                                                      Colors.lightGreen[700]),
                                                  borderRadius:
                                                  BorderRadius.circular(30)),
                                              padding:
                                              EdgeInsets.fromLTRB(7, 2, 7, 2),
                                              child: Text(DEV_STATUS1,
                                                  maxLines: 1,
                                                  style: TextStyle(
                                                      color: Colors.lightGreen[700],
                                                      fontSize: 7,
                                                      fontWeight: FontWeight.bold)),
                                            ),
                                            Container(
                                                margin: EdgeInsets.only(top: 3),
                                                child: Text(
                                                  'Battery : '+DEV_POWER1.toString()+'%',
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: CHARCOAL),
                                                )),
                                          ],
                                        ),
                                        Container(
                                            margin: EdgeInsets.only(top: 10),
                                            child: Text(
                                              DEV_DESC1,
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  color: CHARCOAL),
                                            )),
                                      ],
                                    ),
                                  ),
                                  Icon(
                                    Icons.check,
                                    color: PRIMARY_COLOR,
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ],
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          _showAlertDialog(context);
                        },
                        behavior: HitTestBehavior.translucent,
                        child: Container(
                          margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                          child: Column(
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Container(
                                    margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                                    child: Column(
                                      children: <Widget>[
                                        ImageIcon(
                                          DEV_ICON2,
                                          color: MENU_IMAGES_COLOR,
                                          size: 28,
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Stop',
                                          style: TextStyle(
                                              fontSize: 12, color: CHARCOAL),
                                        )
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                          DEV_NAME2+' ['+SN2+']',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                              color: CHARCOAL),
                                        ),
                                        Row(
                                          children: <Widget>[
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 3, 5, 0),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color:
                                                      Colors.red[900]),
                                                  borderRadius:
                                                  BorderRadius.circular(30)),
                                              padding:
                                              EdgeInsets.fromLTRB(7, 2, 7, 2),
                                              child: Text(DEV_STATUS2,
                                                  maxLines: 1,
                                                  style: TextStyle(
                                                      color: Colors.red[900],
                                                      fontSize: 7,
                                                      fontWeight: FontWeight.bold)),
                                            ),
                                            Container(
                                                margin: EdgeInsets.only(top: 3),
                                                child: Text(
                                                  'Battery : '+DEV_POWER2.toString()+'%',
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: CHARCOAL),
                                                )),
                                          ],
                                        ),
                                        Container(
                                            margin: EdgeInsets.only(top: 10),
                                            child: Text(
                                              DEV_DESC2,
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  color: CHARCOAL),
                                            ))
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ],
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          _showAlertDialog(context);
                        },
                        behavior: HitTestBehavior.translucent,
                        child: Container(
                          margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                          child: Column(
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Container(
                                    margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                                    child: Column(
                                      children: <Widget>[
                                        Icon(
                                          DEV_ICON3,
                                          color: MENU_IMAGES_COLOR,
                                          size: 28,
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Stop',
                                          style: TextStyle(
                                              fontSize: 12, color: CHARCOAL),
                                        )
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                          DEV_NAME3+' ['+SN3+']',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                              color: CHARCOAL),
                                        ),
                                        Row(
                                          children: <Widget>[
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 3, 5, 0),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: OCEAN),
                                                  borderRadius:
                                                  BorderRadius.circular(30)),
                                              padding:
                                              EdgeInsets.fromLTRB(7, 2, 7, 2),
                                              child: Text(DEV_STATUS3,
                                                  maxLines: 1,
                                                  style: TextStyle(
                                                      color: OCEAN,
                                                      fontSize: 7,
                                                      fontWeight: FontWeight.bold)),
                                            ),
                                            Container(
                                                margin: EdgeInsets.only(top: 3),
                                                child: Text(
                                                  'Battery : '+DEV_POWER3.toString()+'%',
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: Colors.red),
                                                ))
                                          ],
                                        ),
                                        Container(
                                            margin: EdgeInsets.only(top: 10),
                                            child: Text(
                                              DEV_DESC3,
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  color: CHARCOAL),
                                            ))
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Container(color: Colors.grey[300], height: 1),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddDevicePage()));
        },
        child: Icon(Icons.add),
        backgroundColor: PRIMARY_COLOR,
      ),
    );
  }

  _showAlertDialog(BuildContext context) {
    // set up the buttons
    Widget cancelButton = FlatButton(
      child: Text('No'),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    Widget continueButton = FlatButton(
      child: Text('Yes'),
      onPressed: () {
        Navigator.pop(context);
        Navigator.of(context, rootNavigator: true).pop();
        Fluttertoast.showToast(msg: 'Success', toastLength: Toast.LENGTH_LONG);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      content: Text('Set this device ?'),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
