/*
This is geofence page
add shimmer loading to makes the loading more beautiful
add shimmer_loading.dart to this pages in folder reuseable

At GestureDetector Widget add attribute below
behavior: HitTestBehavior.translucent
With this, you can hit all space on GestureDetector
If you don't use above attribute, you still can direct to another pages when you click right on the images or text

install plugin in pubspec.yaml
- fluttertoast => to show toast (https://pub.dev/packages/fluttertoast)
- shimmer_loading => to add beautiful loading (https://pub.dev/packages/shimmer)
 */

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:ijtrackerflutter/config/constants.dart';
import 'package:ijtrackerflutter/ui/add_geofence.dart';
import 'package:ijtrackerflutter/ui/edit_geofence.dart';
import 'package:ijtrackerflutter/ui/reuseable/shimmer_loading.dart';

class GeofencePage extends StatefulWidget {
  @override
  _GeofencePageState createState() => _GeofencePageState();
}

class _GeofencePageState extends State<GeofencePage> {
  bool _loading = true;
  Timer _timerDummy;

  @override
  void initState() {
    // this timer function is just for demo, so after 2 second, the shimmer loading will disappear and show the content
    _timerDummy = Timer(Duration(seconds: 2), () {
      setState(() {
        _loading = false;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _timerDummy?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'GEOFENCE',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        backgroundColor: PRIMARY_COLOR,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Text(
                'Geofence List : ',
                style: TextStyle(color: Colors.grey[600]),
              )),
          Expanded(
            child: (_loading == true)
                ? Center(child: ShimmerList())
                : ListView(
              children: <Widget>[
                SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME1,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC1,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT1.toString()+', '+GEO_LNG1.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD1.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME2,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC2,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT2.toString()+', '+GEO_LNG2.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD2.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME3,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC3,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT3.toString()+', '+GEO_LNG3.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD3.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME4,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC4,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT4.toString()+', '+GEO_LNG4.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD4.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME5,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC5,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT5.toString()+', '+GEO_LNG5.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD5.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME6,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC6,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT6.toString()+', '+GEO_LNG6.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD6.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _showDialog(context);
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          GEO_NAME7,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: CHARCOAL),
                        ),
                        Container(
                            margin: EdgeInsets.only(top: 3),
                            child: Text(
                              GEO_DESC7,
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Position : '+GEO_LAT7.toString()+', '+GEO_LNG7.toString(),
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Radius : '+GEO_RAD7.toString()+' m',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        Container(
                            child: Text(
                              'Active : 1',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.grey),
                            )),
                        SizedBox(
                          height: 10,
                        ),
                        Container(color: Colors.grey[300], height: 1),
                      ],
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddGeofencePage()));
        },
        child: Icon(Icons.add),
        backgroundColor: PRIMARY_COLOR,
      ),
    );
  }

  // Show Dialog function
  void _showDialog(context) {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return alert dialog object
        return AlertDialog(
          title: Text('Select Action'),
          content: Container(
            height: 120.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                GestureDetector(
                    onTap: () {
                      Navigator.of(context, rootNavigator: true).pop();
                      Navigator.push(context, MaterialPageRoute(builder: (context) => EditGeofencePage()));
                    },
                    behavior: HitTestBehavior.translucent,
                    child: Text('Edit')),
                GestureDetector(
                    onTap: () {
                      Navigator.of(context, rootNavigator: true).pop();
                      _showAlertDialog(context);
                    },
                    behavior: HitTestBehavior.translucent,
                    child: Text('Delete')),
                GestureDetector(
                    onTap: () {
                      Fluttertoast.showToast(msg: 'Success', toastLength: Toast.LENGTH_LONG);
                      Navigator.of(context, rootNavigator: true).pop();
                    },
                    behavior: HitTestBehavior.translucent,
                    child: Text('Non Active')),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showAlertDialog(BuildContext context) {
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          content: Text('Are you sure to delete ?'),
          actions: [
            FlatButton(
              child: Text('No'),
              onPressed: () {
                Navigator.of(ctx, rootNavigator: true).pop();
              },
            ),
            FlatButton(
              child: Text('Yes'),
              onPressed: () {
                Fluttertoast.showToast(msg: 'Success', toastLength: Toast.LENGTH_LONG);
                Navigator.of(ctx, rootNavigator: true).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
