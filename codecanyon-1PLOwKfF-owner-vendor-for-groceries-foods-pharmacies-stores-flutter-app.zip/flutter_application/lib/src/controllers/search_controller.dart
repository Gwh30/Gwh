import 'package:mvc_pattern/mvc_pattern.dart';

class SearchController extends ControllerMVC {
  SearchController();
}
